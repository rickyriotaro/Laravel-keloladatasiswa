<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rapor Siswa</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .kop-sekolah { text-align: center; margin-bottom: 30px; }
        .kop-sekolah h1 { font-size: 20px; margin: 0; }
        .kop-sekolah p { margin: 5px 0; font-size: 14px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        table, th, td { border: 1px solid rgb(0, 0, 0); }
        th, td { padding: 10px; text-align: center; }
        th { background-color: #ffffff; }
        .footer { margin-top: 40px; text-align: center; }
        .signatures { margin-top: 60px; }
        .row { display: flex; justify-content: space-between; }
        .signature-left { text-align: left; width: 40%; }
        .signature-right { text-align: right; width: 40%; }
        .center-signature { text-align: center; margin-top: 40px; }
        .date { text-align: right; margin-top: 20px; font-style: italic; }
    </style>
</head>
<body>
    <div class="kop-sekolah">
        <h1>SEKOLAH DASAR (SD)</h1>
        <p>Jl. Pendidikan No. 123, Kota Pendidikan</p>
        <p>Telp: (021) 12345678 | Email: info@sekolah.edu</p>
        <p><strong>Tahun Ajaran:</strong> <?php echo e($academicYear); ?></p>
        <hr>
    </div>

    <div class="info-siswa">
        <p><strong>Kelas:</strong> <?php echo e($kelas->nama_kelas); ?></p>
        <p><strong>Nama Siswa:</strong> <?php echo e($siswa->nama_siswa); ?></p>
        <p><strong>NIS:</strong> <?php echo e($siswa->nis); ?></p>
        <p><strong>Semester:</strong> <?php echo e($semester); ?></p>
    </div>
    <h3>Penilaian Sikap</h3>
    <table>
        <thead>
            <tr>
                <th>Jenis Sikap</th>
                <th>Deskripsi</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Sikap Spiritual</td>
                <td><?php echo e($siswa->sikap->spiritual_desc ?? 'Belum ada deskripsi'); ?></td>
            </tr>
            <tr>
                <td>Sikap Sosial</td>
                <td><?php echo e($siswa->sikap->social_desc ?? 'Belum ada deskripsi'); ?></td>
            </tr>
        </tbody>
    </table>

    <h3>Daftar Nilai Akademik</h3>
    <table>
        <thead>
            <tr>
                <th>Pelajaran</th>
                <th>Nilai Pengetahuan</th>
                <th>Prediket Pengetahuan</th>
                <th>Nilai Keterampilan</th>
                <th>Prediket Keterampilan</th>
                <th>Deskripsi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $siswa->nilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($nilai->pelajaran->nama_pelajaran); ?></td>
                    <td><?php echo e($nilai->nilai); ?></td>
                    <td><?php echo e($nilai->prediket); ?></td>
                    <td><?php echo e($nilai->nilai_2); ?></td>
                    <td><?php echo e($nilai->prediket_2); ?></td>
                    <td><?php echo e($nilai->deskripsi); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php if($kkm): ?>
        <h3>Kriteria Ketuntasan Minimal (KKM)</h3>
        <table>
            <thead>
                <tr>
                    <th>Kurang</th>
                    <th>Cukup</th>
                    <th>Baik</th>
                    <th>Sangat Baik</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>&lt; <?php echo e($kkm); ?></td>
                    <td><?php echo e($kkm); ?> - <?php echo e(min($kkm + 10, 100)); ?></td>
                    <td><?php echo e(min($kkm + 11, 100)); ?> - <?php echo e(min($kkm + 20, 100)); ?></td>
                    <td>> <?php echo e(min($kkm + 21, 100)); ?></td>
                </tr>
            </tbody>
        </table>
    <?php endif; ?>

    <h3>Nilai Ekstrakurikuler</h3>
    <table>
        <thead>
            <tr>
                <th>Ekskul</th>
                <th>Nilai</th>
                <th>Deskripsi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $siswa->ekskulScores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ekskulScore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($ekskulScore->ekskul->name); ?></td>
                    <td><?php echo e($ekskulScore->score); ?></td>
                    <td><?php echo e($ekskulScore->description); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <h3>Kehadiran</h3>
    <table>
        <thead>
            <tr>
                <th>Semester</th>
                <th>Sakit</th>
                <th>Alpha</th>
                <th>Izin</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $siswa->attendanceRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($attendance->semester); ?></td>
                    <td><?php echo e($attendance->sakit); ?></td>
                    <td><?php echo e($attendance->alpha); ?></td>
                    <td><?php echo e($attendance->izin); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php if($semester === 'Semester 2'): ?>
    <h3>Keputusan</h3>
    <p>Berdasarkan pencapaian kompetensi semester 1 dan semester 2 , peserta didik </p>
    <?php if($siswa->status_kenaikan === 'Naik'): ?>
    <p><strong>Status Kenaikan:</strong> Naik ke Kelas <?php echo e($siswa->nextKelas->nama_kelas ?? 'Belum ditentukan'); ?></p>
<?php elseif($siswa->status_kenaikan === 'Tinggal'): ?>
    <p><strong>Status Kenaikan:</strong> Tinggal di Kelas <?php echo e($siswa->kelas->nama_kelas); ?></p>
<?php endif; ?>

<?php endif; ?>

    <div class="date">
        <p> <?php echo e(\Carbon\Carbon::now()->format('d-m-Y')); ?></p>
    </div>

    <div class="signatures">
        <div class="row">
            <table style="width: 100%; text-align: center; border-collapse: collapse; border: none;">
                <thead>
                    <tr style="border: none;">
                        <th style="text-align: left; border: none;"><strong>Wali Murid</strong></th>
                        <th style="text-align: right; border: none;"><strong>Wali Kelas</strong></th>
                    </tr>
                </thead>
                <tbody>
                    <tr style="border: none;">
                        <td style="text-align: left; border: none;">&nbsp;</td>
                        <td style="text-align: right; border: none;">&nbsp;</td>
                    </tr>
                    <tr style="border: none;">
                        <td style="text-align: left; border: none;">&nbsp;</td>
                        <td style="text-align: right; border: none;">&nbsp;</td>
                    </tr>
                    <tr style="border: none;">
                        <td style="text-align: left; border: none;"><u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></td>
                        <td style="text-align: right; border: none;"><u><?php echo e($waliKelasName); ?></u></td>
                    </tr>
                </tbody>
            </table>

        </div>
       <center>
        <div >
            <p><strong>Kepala Sekolah</strong></p>
            <br><br>
            <p><u><?php echo e($kepsekName); ?></u></p>
            <p><strong>NIP:</strong> <?php echo e($kepsekNIP); ?></p>
        </div>
       </center>
    </div>

</body>
</html>
<?php /**PATH C:\laragon\www\raportmini\resources\views/rapor/per_siswa.blade.php ENDPATH**/ ?>
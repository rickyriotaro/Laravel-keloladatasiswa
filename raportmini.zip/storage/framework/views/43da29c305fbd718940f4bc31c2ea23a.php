<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Manage KKM')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container mx-auto px-4 py-8">
        <a href="<?php echo e(route('kkm.create')); ?>"
           class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
            Add KKM
        </a>

        <table class="w-full bg-white shadow-md rounded-lg mt-4">
            <thead class="bg-gray-100">
                <tr>
                    <th class="px-6 py-3 text-left text-sm font-medium text-gray-600 uppercase">Kelas</th>
                    <th class="px-6 py-3 text-left text-sm font-medium text-gray-600 uppercase">KKM</th>
                    <th class="px-6 py-3 text-left text-sm font-medium text-gray-600 uppercase">Grade Example</th>
                    <th class="px-6 py-3 text-left text-sm font-medium text-gray-600 uppercase">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $kkms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kkm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b">
                        <td class="px-6 py-4"><?php echo e($kkm->kelas->nama_kelas); ?></td>
                        <td class="px-6 py-4"><?php echo e($kkm->kkm_value); ?></td>
                        <td class="px-6 py-4">
                            <ul>
                                <li>Kurang: &lt;<?php echo e($kkm->kkm_value); ?></li>
                                <li>Cukup: <?php echo e($kkm->kkm_value); ?> - <?php echo e(min($kkm->kkm_value + 10, 100)); ?></li>
                                <li>Baik: <?php echo e(min($kkm->kkm_value + 11, 100)); ?> - <?php echo e(min($kkm->kkm_value + 20, 100)); ?></li>
                                <li>Sangat Baik: &gt;<?php echo e(min($kkm->kkm_value + 20, 100)); ?></li>
                            </ul>
                        </td>

                        <td class="px-6 py-4">
                            <a href="<?php echo e(route('kkm.edit', $kkm->id)); ?>"
                               class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                                Edit
                            </a>
                            <form action="<?php echo e(route('kkm.destroy', $kkm->id)); ?>" method="POST" class="inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                        class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
                                        onclick="return confirm('Are you sure?')">
                                    Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\raportmini\resources\views/kkm/index.blade.php ENDPATH**/ ?>
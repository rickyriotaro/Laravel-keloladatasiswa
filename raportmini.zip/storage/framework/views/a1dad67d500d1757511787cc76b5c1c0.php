<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nilai Pengetahuan Siswa</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .kop-sekolah {
            text-align: center;
            margin-bottom: 20px;
        }
        .kop-sekolah h1 {
            font-size: 24px;
            margin: 0;
        }
        .kop-sekolah p {
            margin: 5px 0;
            font-size: 14px;
        }
        .kop-sekolah hr {
            margin: 20px 0;
            border: 1px solid #000;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            text-align: center;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
        .container {
            margin: auto;
        }
    </style>
</head>
<body onload="window.print()">
    <div class="container">
        <!-- Kop Sekolah -->
        <div class="kop-sekolah">
            <h1>SEKOLAH DASAR (SD)</h1>
            <p>Jl. Pendidikan No. 123, Kota Pendidikan</p>
            <p>Telp: (021) 12345678 | Email: info@sekolah.edu</p>
            <hr>
        </div>

        <center><h3>Nilai Pengetahuan Siswa</h3></center>
        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h4>Kelas <?php echo e($k->nama_kelas); ?></h4>
            <table>
                <thead>
                    <tr>
                        <th>Nama Siswa</th>
                        <?php $__currentLoopData = $k->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e($subject->nama_pelajaran); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th>Rata-rata</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $k->siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($siswa->nama_siswa); ?></td>
                            <?php $__currentLoopData = $k->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td>
                                    <?php
                                        $grade = $siswa->nilai->firstWhere('pelajaran_id', $subject->id);
                                    ?>
                                    <?php echo e($grade->nilai ?? '-'); ?>

                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e(number_format($siswa->average, 2)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>Rata-rata Per Pelajaran</th>
                        <?php $__currentLoopData = $k->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e(number_format($subject->average, 2)); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td></td>
                    </tr>
                </tfoot>
            </table>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\raportmini\resources\views\rapor\print_grades.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Tambah Nilai Ekskul')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold mb-6">Tambah Nilai Ekskul untuk Kelas <?php echo e($kelas->nama_kelas); ?></h1>

        <form method="POST" action="<?php echo e(route('rapor.storeEkskulScore')); ?>" class="space-y-4 bg-white shadow-md rounded-lg p-6">
            <?php echo csrf_field(); ?>

            <!-- Siswa Dropdown -->
            <div>
                <label for="siswa_id" class="block text-sm font-medium text-gray-700">Siswa</label>
                <select id="siswa_id" name="siswa_id" required class="w-full mt-1 border-gray-300 rounded-md shadow-sm">
                    <option value="">Pilih Siswa</option>
                    <?php $__currentLoopData = $kelas->siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($siswa->id); ?>"><?php echo e($siswa->nama_siswa); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <!-- Ekskul Dropdown -->
            <div>
                <label for="ekskul_id" class="block text-sm font-medium text-gray-700">Ekskul</label>
                <select id="ekskul_id" name="ekskul_id" required class="w-full mt-1 border-gray-300 rounded-md shadow-sm">
                    <option value="">Pilih Ekskul</option>
                    <?php $__currentLoopData = $ekskuls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ekskul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($ekskul->id); ?>"><?php echo e($ekskul->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <!-- Semester Dropdown -->
            <div>
                <label for="semester" class="block text-sm font-medium text-gray-700">Semester</label>
                <select id="semester" name="semester" required class="w-full mt-1 border-gray-300 rounded-md shadow-sm">
                    <option value="Semester 1">Semester 1</option>
                    <option value="Semester 2">Semester 2</option>
                </select>
            </div>

            <!-- Score Input -->
            <div>
                <label for="score" class="block text-sm font-medium text-gray-700">Nilai</label>
                <input type="number" id="score" name="score" required class="w-full mt-1 border-gray-300 rounded-md shadow-sm">
            </div>

            <!-- Description Textarea -->
            <div>
                <label for="description" class="block text-sm font-medium text-gray-700">Keterangan</label>
                <textarea id="description" name="description" class="w-full mt-1 border-gray-300 rounded-md shadow-sm"></textarea>
            </div>

            <!-- Submit Button -->
            <div class="flex justify-end">
                <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                    Simpan
                </button>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\raportmini\resources\views\rapor\create_ekskul_score.blade.php ENDPATH**/ ?>
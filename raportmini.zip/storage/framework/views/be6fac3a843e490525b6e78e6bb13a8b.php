<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rapor Kelas <?php echo e($kelas->nama_kelas); ?> - <?php echo e($semester); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .kop-sekolah {
            text-align: center;
            margin-bottom: 20px;
        }
        .kop-sekolah h1 {
            font-size: 20px;
            margin: 0;
        }
        .kop-sekolah p {
            font-size: 14px;
            margin: 5px 0;
        }
        .rapor {
            margin-bottom: 20px;
        }
        .rapor h2 {
            margin: 0 0 10px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            text-align: center;
            padding: 8px;
        }
        th {
            background-color: #f0f0f0;
        }
        .footer {
            margin-top: 40px;
            text-align: right;
        }
    </style>
</head>
<body>
    <!-- Kop Sekolah -->
    <div class="kop-sekolah">
        <h1>SEKOLAH DASAR (SD)</h1>
        <p>Jl. Pendidikan No. 123, Kota Pendidikan</p>
        <p>Telp: (021) 12345678 | Email: info@sekolah.edu</p>
        <hr>
    </div>

    <!-- Rapor Per Siswa -->
    <?php $__currentLoopData = $siswaList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="rapor">
            <h2>Rapor Siswa: <?php echo e($siswa->nama_siswa); ?></h2>
            <p><strong>Kelas:</strong> <?php echo e($kelas->nama_kelas); ?></p>
            <p><strong>Semester:</strong> <?php echo e($semester); ?></p>
            <p><strong>NIS:</strong> <?php echo e($siswa->nis); ?></p>

            <!-- Tabel Nilai -->
            <table>
                <thead>
                    <tr>
                        <th>Pelajaran</th>
                        <th>Nilai</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $siswa->nilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($nilai->pelajaran->nama_pelajaran); ?></td>
                            <td><?php echo e($nilai->nilai); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Footer -->
    <div class="footer">
        <p><strong>Kepala Sekolah</strong></p>
        <br><br><br>
        <p><u>(Nama Kepala Sekolah)</u></p>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\raportmini\resources\views\rapor\per_siswa_batch.blade.php ENDPATH**/ ?>
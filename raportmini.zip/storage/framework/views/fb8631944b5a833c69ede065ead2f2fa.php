<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Edit Kehadiran')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold mb-6">Edit Kehadiran - <?php echo e($siswa->nama_siswa); ?> - <?php echo e($semester); ?></h1>

        <form method="POST" action="<?php echo e(url('rapor/attendance')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="siswa_id" value="<?php echo e($siswa->id); ?>">
            <input type="hidden" name="semester" value="<?php echo e($semester); ?>">

            <label for="sakit" class="block text-sm font-medium text-gray-700">Jumlah Sakit</label>
            <input type="number" name="sakit" id="sakit" value="<?php echo e($attendance->sakit); ?>"
                   class="mb-4 border border-gray-300 rounded-md w-full" required>

            <label for="alpha" class="block text-sm font-medium text-gray-700">Jumlah Alpha</label>
            <input type="number" name="alpha" id="alpha" value="<?php echo e($attendance->alpha); ?>"
                   class="mb-4 border border-gray-300 rounded-md w-full" required>

            <label for="izin" class="block text-sm font-medium text-gray-700">Jumlah Izin</label>
            <input type="number" name="izin" id="izin" value="<?php echo e($attendance->izin); ?>"
                   class="mb-4 border border-gray-300 rounded-md w-full" required>

            <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                Simpan Perubahan
            </button>
            <a href="<?php echo e(url()->previous()); ?>" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                Batal
            </a>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\raportmini\resources\views\rapor\edit_attendance.blade.php ENDPATH**/ ?>
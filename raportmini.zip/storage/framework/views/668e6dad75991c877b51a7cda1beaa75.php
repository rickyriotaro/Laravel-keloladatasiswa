<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Edit Nilai')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold mb-6">Edit Nilai</h1>

        <form action="<?php echo e(route('rapor.updateNilai', $nilai->id)); ?>" method="POST" class="bg-white p-6 rounded-lg shadow-md">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <!-- Nilai 1 -->
            <div class="mb-4">
                <label for="nilai" class="block text-sm font-medium text-gray-700">Nilai Pengetahuan</label>
                <input type="number" name="nilai" id="nilai" value="<?php echo e($nilai->nilai); ?>" required
                       class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md">
            </div>

            <!-- Prediket 1 -->
            <div class="mb-4">
                <label for="prediket" class="block text-sm font-medium text-gray-700">Prediket Pengetahuan</label>
                <input type="text" name="prediket" id="prediket" value="<?php echo e($nilai->prediket); ?>"
                       class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md">
            </div>

            <!-- Nilai 2 -->
            <div class="mb-4">
                <label for="nilai_2" class="block text-sm font-medium text-gray-700">Nilai Keterampilan</label>
                <input type="number" name="nilai_2" id="nilai_2" value="<?php echo e($nilai->nilai_2); ?>"
                       class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md">
            </div>

            <!-- Prediket 2 -->
            <div class="mb-4">
                <label for="prediket_2" class="block text-sm font-medium text-gray-700">Prediket Keterampilan</label>
                <input type="text" name="prediket_2" id="prediket_2" value="<?php echo e($nilai->prediket_2); ?>"
                       class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md">
            </div>

            <!-- Deskripsi -->
            <div class="mb-4">
                <label for="deskripsi" class="block text-sm font-medium text-gray-700">Deskripsi</label>
                <textarea name="deskripsi" id="deskripsi" rows="4"
                          class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md"><?php echo e($nilai->deskripsi); ?></textarea>
            </div>

            <!-- Semester -->
            <div class="mb-4">
                <label for="semester" class="block text-sm font-medium text-gray-700">Semester</label>
                <select name="semester" id="semester" required
                        class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md">
                    <option value="Semester 1" <?php echo e($nilai->semester == 'Semester 1' ? 'selected' : ''); ?>>Semester 1</option>
                    <option value="Semester 2" <?php echo e($nilai->semester == 'Semester 2' ? 'selected' : ''); ?>>Semester 2</option>
                </select>
            </div>

            <!-- Submit Button -->
            <button type="submit"
                    class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg">
                Simpan
            </button>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\raportmini\resources\views\rapor\edit.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Nilai')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold mb-6 text-gray-800">
            Nilai - <?php echo e($pelajaran->nama_pelajaran); ?> - Kelas <?php echo e($kelas->nama_kelas); ?>

        </h1>

        <!-- Tombol Kembali -->
        <a href="<?php echo e(route('rapor.mapelIndex', $kelas->id)); ?>"
           class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded mb-4 block w-fit">
            Kembali ke Halaman Mata Pelajaran
        </a>

        <!-- Tampilkan tombol hanya jika level pengguna adalah walikelas -->
        <?php if(Auth::user()->level === 'walikelas'): ?>
            <a href="<?php echo e(route('rapor.createInputNilai', [$kelas->id, $pelajaran->id])); ?>"
               class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded mb-4 block w-fit">
                Tambah Nilai
            </a>
        <?php endif; ?>

        <!-- Filter -->
        <form method="GET" action="<?php echo e(route('rapor.nilaiIndex', [$kelas->id, $pelajaran->id])); ?>"
              class="mb-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <!-- Filter Nama Siswa -->
            <div>
                <label for="nama_siswa" class="block text-sm font-medium text-gray-700">Nama Siswa</label>
                <input type="text" name="nama_siswa" id="nama_siswa" value="<?php echo e(request('nama_siswa')); ?>"
                       class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm">
            </div>

            <!-- Filter Semester -->
            <div>
                <label for="semester" class="block text-sm font-medium text-gray-700">Semester</label>
                <select name="semester" id="semester" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md">
                    <option value="">Semua Semester</option>
                    <option value="Semester 1" <?php echo e(request('semester') == 'Semester 1' ? 'selected' : ''); ?>>Semester 1</option>
                    <option value="Semester 2" <?php echo e(request('semester') == 'Semester 2' ? 'selected' : ''); ?>>Semester 2</option>
                </select>
            </div>

            <!-- Urutkan Berdasarkan Nilai -->
            <div>
                <label for="sort_nilai" class="block text-sm font-medium text-gray-700">Urutkan Nilai</label>
                <select name="sort_nilai" id="sort_nilai" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md">
                    <option value="">Default</option>
                    <option value="asc" <?php echo e(request('sort_nilai') == 'asc' ? 'selected' : ''); ?>>Nilai Terendah</option>
                    <option value="desc" <?php echo e(request('sort_nilai') == 'desc' ? 'selected' : ''); ?>>Nilai Tertinggi</option>
                </select>
            </div>

            <!-- Tombol Filter -->
            <div class="col-span-full">
                <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                    Terapkan Filter
                </button>
            </div>
        </form>

        <!-- Tabel Nilai -->
        <table class="w-full bg-white shadow-md rounded-lg overflow-hidden">
            <thead class="bg-gray-100">
                <tr>
                    <th class="py-3 px-6 text-left">Nama Siswa</th>
                    <th class="py-3 px-6 text-left">Nilai Pengetahuan</th>
                    <th class="py-3 px-6 text-left">prediket Pengetahuan</th>
                    <th class="py-3 px-6 text-left">Nilai Keterampilan</th>
                    <th class="py-3 px-6 text-left">Prediket Keterampilan</th>
                    <th class="py-3 px-6 text-left">Deskripsi</th>
                    <th class="py-3 px-6 text-left">Semester</th>
                    <?php if(Auth::user()->level === 'walikelas'): ?>
                        <th class="py-3 px-6 text-left">Aksi</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $nilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-gray-50">
                        <td class="py-3 px-6"><?php echo e($n->siswa->nama_siswa); ?></td>
                        <td class="py-3 px-6"><?php echo e($n->nilai); ?></td>
                        <td class="py-3 px-6"><?php echo e($n->prediket); ?></td>
                        <td class="py-3 px-6"><?php echo e($n->nilai_2); ?></td>
                        <td class="py-3 px-6"><?php echo e($n->prediket_2); ?></td>
                        <td class="py-3 px-6"><?php echo e($n->deskripsi); ?></td>
                        <td class="py-3 px-6"><?php echo e($n->semester); ?></td>
                        <?php if(Auth::user()->level === 'walikelas'): ?>
                            <td class="py-3 px-6 flex space-x-2">
                                <!-- Edit -->
                                <a href="<?php echo e(route('rapor.editNilai', $n->id)); ?>"
                                   class="bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-2 px-4 rounded">
                                    Edit
                                </a>
                                <!-- Delete -->
                                <form method="POST" action="<?php echo e(route('rapor.deleteNilai', $n->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit"
                                            class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                                        Hapus
                                    </button>
                                </form>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <!-- Pagination -->
        <div class="mt-4">
            <?php echo e($nilai->appends(request()->query())->links()); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\raportmini\resources\views\rapor\nilai_index.blade.php ENDPATH**/ ?>
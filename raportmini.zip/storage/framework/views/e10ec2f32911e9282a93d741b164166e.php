<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Rapor')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <?php if(session('success')): ?>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                Swal.fire({
                    title: '<?php echo e(session('success.title')); ?>',
                    text: '<?php echo e(session('success.text')); ?>',
                    icon: 'success',
                    confirmButtonText: 'OK'
                });
            });
        </script>
    <?php endif; ?>

    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold mb-6">Rapor</h1>

        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white shadow-md rounded-lg p-6 mb-8">
                <h3 class="text-xl font-semibold mb-4">Kelas <?php echo e($k->nama_kelas); ?></h3>
                <div class="grid gap-4 mb-6">
                    <a href="<?php echo e(route('rapor.mapelIndex', $k->id)); ?>"
                       class="mt-2 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                        Lihat Mata Pelajaran
                    </a>
                    <a href="<?php echo e(route('rapor.allGrades', $k->id)); ?>"
                       class="mt-2 bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-2 px-4 rounded">
                        Lihat Nilai
                    </a>
                    <div>
                        <label for="semester-<?php echo e($k->id); ?>" class="block text-sm font-medium text-gray-700">Pilih Semester:</label>
                        <select id="semester-<?php echo e($k->id); ?>" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm">
                            <option value="Semester 1">Semester 1</option>
                            <option value="Semester 2">Semester 2</option>
                        </select>
                        <button onclick="downloadAllPdfs(<?php echo e($k->id); ?>, document.getElementById('semester-<?php echo e($k->id); ?>').value)"
                                class="mt-2 bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                            Cetak Semua Rapor
                        </button>
                    </div>
                </div>


                <!-- Tabel Siswa -->
                <!-- Tabel Siswa -->
                <div class="flex justify-between items-center mb-4">
                    <form method="GET" action="<?php echo e(route('rapor.index')); ?>" class="flex space-x-2">
                        <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Cari Nama atau NIS"
                               class="border border-gray-300 rounded-md px-4 py-2">
                        <button type="submit"
                                class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-700">Cari</button>
                    </form>
                </div>

                <div>
                    <table class="w-full bg-white shadow-md rounded-lg overflow-hidden">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="px-6 py-3 text-left text-sm font-medium text-gray-600 uppercase tracking-wider">Nama Siswa</th>
                                <th class="px-6 py-3 text-left text-sm font-medium text-gray-600 uppercase tracking-wider">NIS</th>
                                <th class="px-6 py-3 text-left text-sm font-medium text-gray-600 uppercase tracking-wider">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <?php $__currentLoopData = $k->siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-6 py-4"><?php echo e($s->nama_siswa); ?></td>
                                    <td class="px-6 py-4"><?php echo e($s->nis); ?></td>
                                    <td class="px-12 py-4">
                                        <!-- Cetak Rapor -->


                                        <!-- Button Container -->
                                        <div class="flex space-x-2 mt-2">
                                            <form method="GET" action="<?php echo e(url('rapor/cetak/siswa/' . $s->id)); ?>" class="inline-block">
                                                <select name="semester" required class="border border-gray-300 rounded-md">
                                                    <option value="Semester 1">Semester 1</option>
                                                    <option value="Semester 2">Semester 2</option>
                                                </select>
                                                <button type="submit" class="bg-purple-500 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded">
                                                    Cetak Rapor
                                                </button>
                                            </form>
                                            <?php if(Auth::user()->level === 'walikelas'): ?>
                                            <!-- Isi Data Kehadiran -->
                                            <button onclick="openAttendanceModal(<?php echo e($s->id); ?>)"
                                                class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                                                Isi Kehadiran
                                            </button>

                                            <!-- Edit Kehadiran -->
                                            <a href="<?php echo e(route('rapor.attendanceList', $k->id)); ?>"
                                                class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                                                Edit Kehadiran
                                            </a>

                                            <a href="<?php echo e(route('rapor.ekskulList', $k->id)); ?>"
                                                class="bg-pink-500 hover:bg-pink-700 text-white font-bold py-2 px-4 rounded">
                                                Kelola Ekskul
                                            </a>
                                            <a href="<?php echo e(route('sikap.index', $k->id)); ?>"
                                            class="bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-2 px-4 rounded">
                                            Kelola Sikap
                                         </a>
                                         <button onclick="openPromotionModal(<?php echo e($siswa->id); ?>)"
                                            class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                                            Atur Kenaikan Kelas
                                        </button>
                                         <?php endif; ?>
                                        </div>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <div class="mt-4">
                    <?php if($k->siswa instanceof \Illuminate\Pagination\LengthAwarePaginator): ?>
                        <?php echo e($k->siswa->links('pagination::tailwind')); ?>

                    <?php endif; ?>
                </div>


            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div id="promotionModal" class="hidden fixed z-10 inset-0 overflow-y-auto">
        <div class="flex items-center justify-center min-h-screen px-4">
            <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-lg">
                <h3 class="text-lg font-bold mb-4">Keputusan Kenaikan Kelas</h3>
                <form id="promotionForm" method="POST" action="<?php echo e(route('rapor.updatePromotion')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="siswa_id" id="promotion_siswa_id">
                    <label for="status_kenaikan" class="block text-sm font-medium text-gray-700">Status</label>
                    <select name="status_kenaikan" id="status_kenaikan" required class="mb-4 border border-gray-300 rounded-md w-full">
                        <option value="Naik">Naik Kelas</option>
                        <option value="Tinggal">Tinggal Kelas</option>
                    </select>
                    <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                        Simpan
                    </button>
                    <button type="button" onclick="closePromotionModal()"
                        class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                        Batal
                    </button>
                </form>
            </div>
        </div>
    </div>
    <div id="attendanceModal" class="hidden fixed z-10 inset-0 overflow-y-auto">
        <div class="flex items-center justify-center min-h-screen px-4">
            <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-lg">
                <h3 class="text-lg font-bold mb-4">Isi Data Kehadiran</h3>
                <form id="attendanceForm" method="POST" action="<?php echo e(url('rapor/attendance')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="siswa_id" id="siswa_id">
                    <label for="semester" class="block text-sm font-medium text-gray-700">Semester</label>
                    <select name="semester" id="semester" required class="mb-4 border border-gray-300 rounded-md w-full">
                        <option value="Semester 1">Semester 1</option>
                        <option value="Semester 2">Semester 2</option>
                    </select>

                    <label for="sakit" class="block text-sm font-medium text-gray-700">Jumlah Sakit</label>
                    <input type="number" name="sakit" id="sakit" class="mb-4 border border-gray-300 rounded-md w-full">

                    <label for="alpha" class="block text-sm font-medium text-gray-700">Jumlah Alpha</label>
                    <input type="number" name="alpha" id="alpha" class="mb-4 border border-gray-300 rounded-md w-full">

                    <label for="izin" class="block text-sm font-medium text-gray-700">Jumlah Izin</label>
                    <input type="number" name="izin" id="izin" class="mb-4 border border-gray-300 rounded-md w-full">

                    <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                        Simpan
                    </button>
                    <button type="button" onclick="closeAttendanceModal()" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                        Batal
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        function openPromotionModal(siswaId) {
            document.getElementById('promotion_siswa_id').value = siswaId;
            document.getElementById('promotionModal').classList.remove('hidden');
        }

        function closePromotionModal() {
            document.getElementById('promotionModal').classList.add('hidden');
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        function openAttendanceModal(siswaId) {
            document.getElementById('siswa_id').value = siswaId;
            document.getElementById('attendanceModal').classList.remove('hidden');
        }

        function closeAttendanceModal() {
            document.getElementById('attendanceModal').classList.add('hidden');
        }
    </script>

    <script>
        async function downloadRapor(kelasId, semester) {
    try {
        Swal.fire({
            title: 'Mengunduh...',
            text: 'Harap tunggu, sedang mengunduh semua PDF.',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        const response = await fetch(`/rapor/cetak/${kelasId}?semester=${semester}`);
        const data = await response.json();

        if (data.pdfUrls && data.pdfUrls.length > 0) {
            for (const url of data.pdfUrls) {
                const anchor = document.createElement('a');
                anchor.href = url;
                anchor.download = url.split('/').pop(); // Nama file
                document.body.appendChild(anchor);
                anchor.click();
                document.body.removeChild(anchor);
            }

            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: 'Semua PDF berhasil diunduh.',
            });
        } else {
            Swal.fire({
                icon: 'warning',
                title: 'Tidak Ada File',
                text: 'Tidak ada file PDF untuk diunduh.',
            });
        }
    } catch (error) {
        console.error('Error downloading PDFs:', error);
        Swal.fire({
            icon: 'error',
            title: 'Gagal!',
            text: 'Terjadi kesalahan saat mengunduh PDF. Silakan coba lagi.',
        });
    }
}


        async function downloadStudentRapor(studentId) {
            try {
                Swal.fire({
                    title: 'Mengunduh...',
                    text: 'Harap tunggu, sedang mengunduh PDF.',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                const response = await fetch(`/rapor/cetak/siswa/${studentId}`);
                const data = await response.json();

                if (data.pdfUrl) {
                    const anchor = document.createElement('a');
                    anchor.href = data.pdfUrl;
                    anchor.download = data.pdfUrl.split('/').pop();
                    document.body.appendChild(anchor);
                    anchor.click();
                    document.body.removeChild(anchor);

                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil!',
                        text: 'PDF berhasil diunduh.',
                    });
                } else {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Tidak Ada File',
                        text: 'Tidak ada file PDF untuk diunduh.',
                    });
                }
            } catch (error) {
                console.error('Error downloading PDF:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal!',
                    text: 'Terjadi kesalahan saat mengunduh PDF. Silakan coba lagi.',
                });
            }
        }
        async function downloadAllPdfs(kelasId, semester) {
    try {
        Swal.fire({
            title: 'Mengunduh...',
            text: 'Harap tunggu, sedang memproses file PDF.',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        // Ambil daftar URL PDF dari backend
        const response = await fetch(`/rapor/cetak/${kelasId}?semester=${semester}`);
        const data = await response.json();

        if (data.error) {
            Swal.fire({
                icon: 'error',
                title: 'Gagal!',
                text: data.error,
            });
            return;
        }

        if (data.pdfUrls && data.pdfUrls.length > 0) {
            for (const url of data.pdfUrls) {
                // Buat elemen unduhan untuk setiap file
                const anchor = document.createElement('a');
                anchor.href = url;
                anchor.download = url.split('/').pop(); // Nama file
                document.body.appendChild(anchor);
                anchor.click();
                document.body.removeChild(anchor);
            }

            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: 'Semua file PDF telah berhasil diunduh.',
            });
        } else {
            Swal.fire({
                icon: 'warning',
                title: 'Tidak Ada File',
                text: 'Tidak ada file PDF untuk diunduh.',
            });
        }
    } catch (error) {
        console.error('Error downloading PDFs:', error);
        Swal.fire({
            icon: 'error',
            title: 'Gagal!',
            text: 'Terjadi kesalahan saat memproses file PDF.',
        });
    }
}

async function downloadStudentRapor(siswaId, semester) {
    try {
        const response = await fetch(`/rapor/cetak/siswa/${siswaId}?semester=${semester}`);
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const anchor = document.createElement('a');
        anchor.href = url;

        // Nama file sesuai dengan siswa dan semester
        anchor.download = `rapor_siswa_${siswaId}_${semester}.pdf`;
        anchor.click();

        window.URL.revokeObjectURL(url);
    } catch (error) {
        console.error(`Error downloading PDF for siswa ${siswaId}:`, error);
    }
}

    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\raportmini\resources\views\rapor\index.blade.php ENDPATH**/ ?>